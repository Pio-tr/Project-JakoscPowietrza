var annotated_dup =
[
    [ "ChartWindow", "class_chart_window.html", "class_chart_window" ],
    [ "DataPoint", "struct_data_point.html", null ],
    [ "DataWorker", "class_data_worker.html", "class_data_worker" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ]
];