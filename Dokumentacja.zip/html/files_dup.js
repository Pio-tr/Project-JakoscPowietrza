var files_dup =
[
    [ "chartwindow.cpp", "chartwindow_8cpp.html", null ],
    [ "chartwindow.h", "chartwindow_8h.html", "chartwindow_8h" ],
    [ "dataworker.cpp", "dataworker_8cpp.html", null ],
    [ "dataworker.h", "dataworker_8h.html", "dataworker_8h" ],
    [ "jsonstorage.cpp", "jsonstorage_8cpp.html", null ],
    [ "jsonstorage.h", "jsonstorage_8h.html", "jsonstorage_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ]
];