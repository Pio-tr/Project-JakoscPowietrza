var class_data_worker =
[
    [ "DataWorker", "class_data_worker.html#acc8d6fe8ea26f67b6579b289e30941f3", null ],
    [ "dataReady", "class_data_worker.html#a4164da571c826c606baa38f74c916248", null ],
    [ "start", "class_data_worker.html#aa5f7c2be091b19e2644682d4e012c67b", null ]
];