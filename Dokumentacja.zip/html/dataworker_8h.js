var dataworker_8h =
[
    [ "DataPoint", "struct_data_point.html", null ],
    [ "DataWorker", "class_data_worker.html", "class_data_worker" ]
];