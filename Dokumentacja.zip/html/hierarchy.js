var hierarchy =
[
    [ "DataPoint", "struct_data_point.html", null ],
    [ "JsonStorage", "class_json_storage.html", null ],
    [ "QDialog", null, [
      [ "ChartWindow", "class_chart_window.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "DataWorker", "class_data_worker.html", null ]
    ] ]
];