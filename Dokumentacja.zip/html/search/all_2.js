var searchData=
[
  ['getjsondir_0',['getJsonDir',['../jsonstorage_8cpp.html#ac463259c21f2fbfd2ce0d318be65031c',1,'getJsonDir():&#160;jsonstorage.cpp'],['../jsonstorage_8h.html#ac463259c21f2fbfd2ce0d318be65031c',1,'getJsonDir():&#160;jsonstorage.cpp']]],
  ['getjsonfilepath_1',['getJsonFilePath',['../jsonstorage_8cpp.html#ad0332070a69d3bef9eaa6fa39da53b98',1,'getJsonFilePath(const QString &amp;filename):&#160;jsonstorage.cpp'],['../jsonstorage_8h.html#ad0332070a69d3bef9eaa6fa39da53b98',1,'getJsonFilePath(const QString &amp;filename):&#160;jsonstorage.cpp']]]
];
