var searchData=
[
  ['savejsondoc_0',['saveJsonDoc',['../jsonstorage_8cpp.html#a2ab41bc1bcf914007f9658d1a2c47820',1,'saveJsonDoc(const QString &amp;filename, const QJsonArray &amp;array):&#160;jsonstorage.cpp'],['../jsonstorage_8h.html#a2ab41bc1bcf914007f9658d1a2c47820',1,'saveJsonDoc(const QString &amp;filename, const QJsonArray &amp;array):&#160;jsonstorage.cpp']]],
  ['savemeasurements_1',['saveMeasurements',['../jsonstorage_8cpp.html#ad97c48ff6207be0288a4ac01661a56ad',1,'saveMeasurements(int stationId, int sensorId, const QVector&lt; DataPoint &gt; &amp;points):&#160;jsonstorage.cpp'],['../jsonstorage_8h.html#ad97c48ff6207be0288a4ac01661a56ad',1,'saveMeasurements(int stationId, int sensorId, const QVector&lt; DataPoint &gt; &amp;points):&#160;jsonstorage.cpp']]],
  ['savesensors_2',['saveSensors',['../jsonstorage_8cpp.html#af6eee3a1a081a1756fdc4a2c4a571530',1,'saveSensors(int stationId, const QJsonArray &amp;sensors):&#160;jsonstorage.cpp'],['../jsonstorage_8h.html#af6eee3a1a081a1756fdc4a2c4a571530',1,'saveSensors(int stationId, const QJsonArray &amp;sensors):&#160;jsonstorage.cpp']]],
  ['savestation_3',['saveStation',['../jsonstorage_8cpp.html#a14d7186f0bf16d195f85a6c37ef80f26',1,'saveStation(const QJsonArray &amp;stations):&#160;jsonstorage.cpp'],['../jsonstorage_8h.html#a14d7186f0bf16d195f85a6c37ef80f26',1,'saveStation(const QJsonArray &amp;stations):&#160;jsonstorage.cpp']]],
  ['start_4',['start',['../class_data_worker.html#aa5f7c2be091b19e2644682d4e012c67b',1,'DataWorker']]]
];
