var searchData=
[
  ['datapoint_0',['DataPoint',['../struct_data_point.html',1,'']]],
  ['dataworker_1',['DataWorker',['../class_data_worker.html',1,'']]]
];
